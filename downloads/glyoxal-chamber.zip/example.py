# %% [markdown]
# <a id="after-glyoxal-dilution-two-models-predict-rising-organic-mass-per-sulfate-as-measurements-fall"></a>
#
# ![Change in organic mass per sulfate after dilution: the chamber measurement and growth-calibrated fit fall below their starting values. The reversible-pool model and its imidazole-producing variant (IC) both rise.](../../../images/glyoxal-chamber/graphical-abstract.svg)
#
# Galloway et al. measured how much organic material wet ammonium sulfate
# particles retained when the surrounding glyoxal vapor was diluted. In our digitization
# of Figure 6, median organic mass per unit sulfate fell **10.2%** between
# the 20 minutes before dilution and the final 20-minute sampling window. Fitting a reversible reservoir to
# particle growth before dilution predicted a **6.7% decline** with its
# parameters fixed. Two models using published uptake and reaction parameters
# gave the opposite response to the same measured vapor history. Organic mass
# per sulfate rose **32%** with reversible storage alone and **87%** when
# particles could also form an imidazole product. Dilution thus tests how
# quickly the modeled particles can release what they accumulated during growth.
# Each percentage uses that series’ own pre-dilution value.
#
# ## How dilution revealed reversible uptake in a dark chamber
#
# Galloway and colleagues exposed wet ammonium sulfate seed to glyoxal in the
# dark. In experiment 3 they diluted the chamber after nearly 12 hours and
# followed vapor concentration, particle organic mass and a nitrogen-containing
# fragment. In Figure 6 the organic-to-sulfate ratio turns down while the
# fragment signal continues to rise. The simultaneous changes let us ask
# whether a model can reproduce a falling organic-to-sulfate ratio while
# the sulfate-normalized nitrogen fragment signal at m/z 68 keeps rising.
# [Galloway et al., Table 1 and Figure 6](https://acp.copernicus.org/articles/9/3331/2009/acp-9-3331-2009.pdf#page=7)
#
# ## Can the growth history predict release after dilution?
#
# <a id="recover-the-measurements-and-start-with-wet-seed"></a>
#
# ### The measured gas concentration drives the particle calculation
#
# Table 1 reports 293 K, 56% RH, a calculated 37% liquid water fraction and
# 87 µm³ of wet seed per cm³ of air. We use this water fraction by volume,
# additive volumes, 1 atm, and a representative wet radius of 100 nm. Sulfate
# normalizes the particle measurements, cancelling proportional seed losses.
# Radius is an assumption. The number of represented particles follows from
# the measured volume. Figure 6 gas markers specify the forcing in ppbv.

# %%
import json
from copy import deepcopy
from pathlib import Path
from typing import NamedTuple

import matplotlib.pyplot as plt
import numpy as np
import particula as par
from particula.dynamics.chemistry import ReactionMechanism
from particula.dynamics.chemistry.process import ChemistrySolver
from particula.dynamics.chemistry.resolved import ResolvedChemistry
from particula.dynamics.chemistry.resolved_adapter import (
    ResolvedChemistryAdapter,
)
from particula.dynamics.condensation.species_mapping import (
    CondensationSpeciesMap,
)
from scipy.optimize import brentq, least_squares
from scipy.signal import lfilter

TEMPERATURE = 293.0
PRESSURE = 101325.0
R = 8.31446261815324
DILUTION = 710.04  # minutes from the black line in Figure 6
END = 1540  # last full ten-minute interval observed by all three series
VOLUME = 4 * np.pi * (100e-9) ** 3 / 3
COUNT = 87e-12 / VOLUME  # wet seed volume per m³ of chamber air
LANES = ("dissolved", "bound", "salt", "acid", "water", "IC")
DENSITY = np.array([1690.0, 1690.0, 1770.0, 1830.0, 1000.0, 1400.0])
# Dry-equivalent molecular masses; use the same atomic weights in all budgets.
ELEMENTS = np.array(
    [
        [2, 2, 0, 2, 0],
        [2, 2, 0, 2, 0],
        [0, 8, 2, 4, 1],
        [0, 2, 0, 4, 1],
        [0, 2, 0, 1, 0],
        [4, 4, 2, 1, 0],
    ]
)
MW = ELEMENTS @ (np.array([12.011, 1.008, 14.007, 15.999, 32.06]) / 1000)
SULFATE_MW = (32.06 + 4 * 15.999) / 1000
# Yu et al. Table S2: measured IC production in units of 1e-8 M/s at
# 1.5 M glyoxal and 2 M ammonium, except 3.5 which uses the 1 M glyoxal row.
YU = {
    1.9: (0.067, 1.5),
    2.8: (0.791, 1.5),
    3.5: (4.54, 1.0),
    4.0: (13.2, 1.5),
    4.5: (49.1, 1.5),
}


def inputs():
    """Locate the same data in the checkout, notebook kernel or download."""
    starts = [Path.cwd()]
    if "__file__" in globals():
        starts.append(Path(__file__).resolve().parent)
    for start in starts:
        for parent in (start, *start.parents):
            path = parent / "docs/data/glyoxal-chamber"
            if (path / "mechanism.json").is_file():
                return path
    raise FileNotFoundError(
        "Extract the bundle including docs/data/glyoxal-chamber"
    )


def observations():
    return {
        name: np.loadtxt(inputs() / (name + ".csv"), delimiter=",", skiprows=1)
        for name in ("gas_ppbv", "organic_per_sulfate", "marker68_per_sulfate")
    }


def initial_state(ppbv, nitrogen=True):
    mass = np.zeros(6)
    mass[2] = VOLUME * 0.63 * DENSITY[2]
    mass[4] = VOLUME * 0.37 * DENSITY[4]
    if not nitrogen:
        # Preserve sulfate equivalents and water in the chemical knockout.
        mass[3] = mass[2] * MW[3] / MW[2]
        mass[2] = 0
    gas = par.gas.GasData(
        ["glyoxal"], MW[:1].copy(), np.array([[gas_kg(ppbv)]]), np.array([True])
    )
    particles = par.particles.ParticleData(
        masses=mass.reshape(1, 1, -1),
        density=DENSITY.copy(),
        concentration=np.array([[COUNT]]),
        charge=np.zeros((1, 1)),
        volume=np.ones(1),
        distribution_type="particle_resolved",
    )
    env = par.gas.EnvironmentData(
        temperature=np.array([TEMPERATURE]),
        pressure=np.array([PRESSURE]),
        saturation_ratio=np.zeros((1, 1)),
    )
    return par.Aerosol(particles=particles, gas=gas, environment=env)


def gas_kg(ppbv):
    return ppbv * 1e-9 * PRESSURE * MW[0] / (R * TEMPERATURE)


# %% [markdown]
# <a id="give-condensation-and-chemistry-distinct-material-transfers"></a>
#
# ### Two particle models share a reversible reservoir
#
# Only kinetic condensation exchanges vapor with the dissolved pool. On this
# seed the initial salt molality exceeds 12 mol/kg water. Following Kampf et
# al. and the implementation in Knote et al., cap salting-in at 12, assign a
# bound/dissolved equilibrium ratio of 0.5 and use relaxation times of 44,000
# and 47,000 s initially. Recompute the remaining salt molality as chemistry
# consumes ammonium sulfate and releases water. Below 12 mol/kg the ratio is
# one and the two times are 250 and 5500 s. The contribution of residual
# acid to salting-in is uncharacterized here. Divide total Henry capacity between the pools once. Dissolved
# masses count glyoxal equivalents, including rapid hydration implicitly.
# [Partitioning measurements](https://doi.org/10.1021/es400083d) ·
# [Two-pool parameterization, equations 1–4](https://doi.org/10.5194/acp-14-6213-2014)
#
# Convert the water-volume Henry law into an effective pressure for the native
# mole-fraction activity strategy at the beginning of each outer step. As a
# result the equilibrium surface pressure is dissolved moles divided by water
# volume and Henry capacity. Match the native condensation flux slope to the
# measured monomer relaxation time by solving for an effective accommodation
# coefficient at the current size and composition. This coefficient includes
# condensed-phase resistance. Use a flat
# interface limit for this bulk-solution equilibrium comparison.
#
# The second pathway uses finite ammonium sulfate. Per mole of 1H-imidazole-2-carboxaldehyde (IC), two glyoxal
# and one salt formula unit produce IC, three waters and one sulfuric acid
# equivalent. The acid lane accounts for the sulfate and protons left when two
# ammonias are consumed. Prescribed pH controls the rate. Acid equivalents
# do not specify aqueous speciation. At each pH, derive the conditional rate
# from the published initial rate at 2 M ammonium, carry its activity
# coefficient as fixed, and extrapolate with the measured second orders in
# glyoxal and ammonium. Two ammoniums per salt and M-to-SI conversion enter
# the coefficient. This extrapolation to concentrated aerosol is uncertain.
# [Product kinetics and initial rates](https://doi.org/10.1021/es200989n)


# %%
class Partition(NamedTuple):
    """Equilibrium and relaxation parameters for the current solution."""

    salt_molal: float
    henry: float
    ratio: float
    tau_monomer: float
    tau_bound: float


def partition(state):
    mass = state.particles.masses[0, 0]
    salt = mass[2] / MW[2] / mass[4]
    ratio, tau1, tau2 = (
        (0.5, 44000.0, 47000.0) if salt >= 12 else (1.0, 250.0, 5500.0)
    )
    henry = 4.19e5 * 10 ** (0.24 * min(12.0, salt)) / (1 + ratio)
    return Partition(salt, henry, ratio, tau1, tau2)


def product_k(ph):
    rate, gly = YU[ph]
    # At 2 M NH4 the concentration of salt formula units is 1 M.
    return rate * 1e-8 / gly**2 / 1000**3


def chemistry(state, ph, enabled, high_salt=True):
    record = json.loads((inputs() / "mechanism.json").read_text())
    record["reactions"][-1]["rate"]["k"] = product_k(ph) if enabled else 0.0
    if not high_salt:
        for reaction in record["reactions"][:2]:
            reaction["rate"]["k"] = 1 / 5500.0
    mechanism = ReactionMechanism.from_dict(record)
    bound = mechanism.bind_resolved(
        state, {"particle:" + s: i for i, s in enumerate(LANES)}
    )
    return ResolvedChemistry(bound, ChemistrySolver(rtol=1e-7, atol=1e-12))


def condensation(state, alpha):
    mass = state.particles.masses[0, 0]
    water_liters = 1000 * mass[4] / DENSITY[4]
    reference_pa = (
        PRESSURE * (mass / MW).sum() / (water_liters * partition(state).henry)
    )
    return par.dynamics.CondensationIsothermal(
        molar_mass=MW[:1].copy(),
        accommodation_coefficient=alpha,
        activity_strategy=par.particles.ActivityIdealMolar(MW.copy()),
        vapor_pressure_strategy=par.gas.ConstantVaporPressureStrategy(
            reference_pa
        ),
        surface_strategy=par.particles.SurfaceStrategyVolume(
            surface_tension=1e-12, density=1000.0
        ),
        species_map=CondensationSpeciesMap(("glyoxal",), ((0, 0),)),
    )


def flux(state, alpha):
    return condensation(state, alpha).mass_transfer_rate(
        state.particles, state.gas, TEMPERATURE, PRESSURE
    )[0, 0]


def exchange_coefficient(state):
    """Match the native slope d(flux)/d(partial pressure) to the measured pool time."""
    mass = state.particles.masses[0, 0]
    params = partition(state)
    capacity = params.henry * mass[4] * MW[0]  # kg per atm at 1 kg/L water
    probe = deepcopy(state.gas)
    # A prescribed 100 ppbv excess above equilibrium gives a well-conditioned
    # slope even when the actual atmosphere is at or below equilibrium.
    probe.concentration[0, 0] = gas_kg(100.0 + mass[0] / capacity * 1e9)
    expected = capacity * 1e-7 / params.tau_monomer

    def residual(alpha):
        rate = condensation(state, alpha).mass_transfer_rate(
            state.particles, probe, TEMPERATURE, PRESSURE
        )[0, 0]
        return rate / expected - 1

    return brentq(residual, 1e-13, 1, xtol=1e-15)


def ledger(state):
    """Total kg and moles of C, H, N, O and S per m³ of air."""
    mass = state.particles.masses[0, 0] * COUNT
    gas = state.gas.concentration[0, 0]
    return np.r_[
        mass.sum() + gas, (mass / MW) @ ELEMENTS + gas / MW[0] * ELEMENTS[0]
    ]


# %% [markdown]
# <a id="replay-the-chamber-and-close-the-forced-budget"></a>
#
# ### The same sampling windows test both particle models
#
# Use linear interpolation between gas measurements. Prescribe the midpoint
# concentration for each interval, then let the finite gas and particles
# evolve together. Record the difference at each prescription as an external
# gas exchange. Reprepare the CUDA sequence at each interval to refresh the
# effective Henry pressure using the current composition. Every chemistry and
# condensation step on that backend runs on the GPU. Observation and forcing
# explicitly cross the device boundary.
#
# Report organic mass per sulfate mass and IC per initial sulfate. Use the
# same two 20-minute windows for measured and simulated organic decline, one
# immediately preceding dilution and one at the end. Retain the raw marker
# scatter and compare its direction with modeled product accumulation.


# %%
def decline(trace):
    t, y = np.transpose(trace)
    initial = np.median(y[(t >= DILUTION - 20) & (t <= DILUTION)])
    final = np.median(y[(t >= END - 20) & (t <= END)])
    return float(100 * (1 - final / initial))


def replay(gas, device, dt, ph=3.5, enabled=True, nitrogen=True, end=END):
    state = initial_state(np.interp(0, *gas.T), nitrogen)
    initial_alpha = exchange_coefficient(state)
    reactions = {
        high: chemistry(state, ph, enabled, high) for high in (True, False)
    }
    registry = par.ProcessRegistry()
    registry.register(ResolvedChemistry, ResolvedChemistryAdapter())
    baseline = ledger(state)
    sulfate = (state.particles.masses[0, 0, 2:4] / MW[2:4]).sum() * SULFATE_MW
    gas_unit = np.r_[1.0, ELEMENTS[0] / MW[0]]
    forced = 0.0
    supplied = removed = evaporated = 0.0
    worst = 0.0
    rows = []
    seconds = 0.0
    while True:
        params = partition(state)
        minutes = seconds / 60
        mass = state.particles.masses[0, 0]
        if np.any(mass < 0) or state.gas.concentration.min() < 0:
            raise ValueError("Negative gas or particle inventory")
        if minutes % 5 == 0:
            rows.append(
                [
                    minutes,
                    mass[[0, 1, 5]].sum() / sulfate,
                    mass[5] / sulfate,
                    mass[0] / sulfate,
                    mass[1] / sulfate,
                    forced,
                    supplied,
                    removed,
                    evaporated,
                    params.salt_molal,
                ]
            )
        balance = ledger(state) - baseline - forced * gas_unit
        scale = np.maximum(np.abs(baseline) + np.abs(forced * gas_unit), 1e-30)
        worst = max(worst, float(np.max(np.abs(balance) / scale)))
        if seconds >= end * 60:
            break
        # Resolve the change to the faster pool times over the same saved mesh.
        h = min(dt if params.salt_molal >= 12.5 else dt / 8, end * 60 - seconds)
        target = gas_kg(np.interp(minutes + h / 120, *gas.T))
        delta = target - state.gas.concentration[0, 0]
        supplied += max(delta, 0.0)
        removed += max(-delta, 0.0)
        forced += delta
        state.gas.concentration[0, 0] = target
        transfer = par.dynamics.MassCondensation(
            condensation(state, exchange_coefficient(state))
        )
        reaction = reactions[params.salt_molal >= 12]
        if device == "numpy":
            transfer.execute(state, h)
            reaction.execute(state, h)
        else:
            with (transfer | reaction).prepare(
                state, device=device, time_step=h, process_registry=registry
            ) as sim:
                sim.step()
                state = sim.snapshot()
        seconds += h
        evaporated += max(state.gas.concentration[0, 0] - target, 0.0)
    if worst > 2e-10:
        raise AssertionError(f"Relative forced inventory error {worst}")
    return np.array(rows), worst, initial_alpha


def independent_checks():
    """Test the Henry zero, evaporation and a held-out Yu laboratory rate."""
    state = initial_state(100.0)
    mass = state.particles.masses[0, 0]
    alpha = exchange_coefficient(state)
    mass[0] = partition(state).henry * 100e-9 * mass[4] * MW[0]
    equilibrium_flux = flux(state, alpha)
    state.gas.concentration[0, 0] *= 0.5
    negative_flux = flux(state, alpha)
    assert negative_flux < 0 and abs(equilibrium_flux / negative_flux) < 1e-9
    before = mass[0]
    par.dynamics.MassCondensation(condensation(state, alpha)).execute(
        state, 60.0
    )
    assert state.particles.masses[0, 0, 0] < before

    # Independent initial-rate row: 1.5 M glyoxal and 1 M salt (2 M NH4).
    mass = state.particles.masses[0, 0]
    mass[:] = 0
    mass[[0, 2]] = np.array([1500.0, 1000.0]) * MW[[0, 2]] * VOLUME
    mass[4] = (VOLUME - (mass / DENSITY).sum()) * DENSITY[4]
    seconds = 0.1
    chemistry(state, 3.5, True).execute(state, seconds)
    rate = state.particles.masses[0, 0, 5] / (MW[5] * VOLUME * 1000 * seconds)
    assert abs(rate - 9.74e-8) <= 0.90e-8
    return {
        "IC_M_per_s": float(rate),
        "Henry_flux_kg_s": float(equilibrium_flux),
        "half_vapor_flux_kg_s": float(negative_flux),
    }


# %% [markdown]
# <a id="estimate-a-reversible-response-from-chamber-growth"></a>
#
# ### A fit to the growth period predicts part of the later decline
#
# At dilution the measured organic/sulfate ratio is about 3.07. With the
# assumed water and sulfate, the literature-based reversible run has reached
# only 0.65. Even at equilibrium with the measured 174 ppbv of vapor, its
# capacity would be about 1.47. Its two initial relaxation times are 12 and
# 13 hours, comparable to the time between seed injection and dilution.
#
# How well can one reversible reservoir describe this chamber? Let $q$ be
# organic/sulfate and $G(t)$ the measured vapor in ppbv. Model the response
# as $dq/dt=(K G(t)-q)/\tau$, starting with clean seed at $q(0)=0$.
# Estimate positive capacity $K$ and response time $\tau$ by least squares
# on particle observations from injection to the dilution line. Each marker
# has equal weight. Continue from the fitted state with both parameters fixed
# and the measured vapor as input. Particle observations after dilution
# enter only the comparison. This empirical calculation describes the total
# organic response and makes no prediction of IC abundance.


# %%
def chamber_response(gas, organic):
    """Fit one reversible pool before dilution and predict through the end."""
    sample_time, ratio = organic.T
    growth = (sample_time >= 0) & (sample_time <= DILUTION)
    dt_min = 0.25
    grid = np.arange(0, END + dt_min, dt_min)
    vapor = np.interp(grid, *gas.T)
    mean_vapor = (vapor[:-1] + vapor[1:]) / 2

    def trajectory(log_params, interval_vapor):
        capacity, tau_min = np.exp(log_params)
        # Relax exactly to the interval-mean vapor target over 15 seconds.
        fraction = -np.expm1(-dt_min / tau_min)
        response = lfilter(
            [capacity * fraction], [1, fraction - 1], interval_vapor
        )
        return np.r_[0.0, response]

    stop = np.searchsorted(grid, sample_time[growth][-1]) + 1

    def residual(params):
        q = trajectory(params, mean_vapor[: stop - 1])
        return np.interp(sample_time[growth], grid[:stop], q) - ratio[growth]

    fit = least_squares(residual, np.log([0.02, 200.0]))
    if not fit.success:
        raise RuntimeError(f"Chamber response fit failed: {fit.message}")
    capacity, tau_min = np.exp(fit.x)
    q = trajectory(fit.x, mean_vapor)
    predicted = np.interp(sample_time, grid, q)
    windows = [(DILUTION - 20, DILUTION), (END - 20, END)]
    medians = [
        float(np.median(predicted[(sample_time >= lo) & (sample_time <= hi)]))
        for lo, hi in windows
    ]
    # Keep five-minute plot samples plus the exact split point in the download.
    plot_time = np.union1d(grid[::20], [DILUTION])
    return {
        "capacity_ratio_per_ppbv": float(capacity),
        "tau_hours": float(tau_min / 60),
        "fit_end_min": DILUTION,
        "fit_count": int(growth.sum()),
        "fit_rmse": float(np.sqrt(np.mean(fit.fun**2))),
        "window_ratios": medians,
        "decline_pct": decline(np.column_stack((sample_time, predicted))),
        "history": np.column_stack(
            (plot_time, np.interp(plot_time, grid, q))
        ).tolist(),
    }


def simulate():
    """Qualify a replay using the same observation windows on both devices."""
    obs = observations()
    gas = obs["gas_ppbv"]
    ot, oy = obs["organic_per_sulfate"].T
    measured = decline(obs["organic_per_sulfate"])
    pre = np.median(oy[(ot >= DILUTION - 20) & (ot <= DILUTION)])
    post = np.median(oy[(ot >= END - 20) & (ot <= END)])
    # Conservative center-location allowance in each window, propagated to %.
    dy = 0.15 * 3.5 / (179.135986 - 77.244982)
    resolution = 100 * ((post + dy) / (pre - dy) - post / pre)
    report = {
        "observed": {k: v.tolist() for k, v in obs.items()},
        "measured_decline_pct": measured,
        "chamber_fit": chamber_response(gas, obs["organic_per_sulfate"]),
        "digitizing_pp": float(resolution),
        "checks": independent_checks(),
        "runs": {},
        "pH_sensitivity": {},
    }
    for device in ("numpy", "cuda:0"):
        backend = {}
        for name in ("reversible", "IC"):
            previous = None
            for dt in (150, 75):
                rows, err, alpha = replay(gas, device, dt, enabled=name == "IC")
                predicted = decline(
                    np.column_stack((ot, np.interp(ot, rows[:, 0], rows[:, 1])))
                )
                if (
                    previous is not None
                    and abs(predicted - previous) >= resolution
                ):
                    raise AssertionError(
                        f"{device} {name}: refine timestep further"
                    )
                if name == "reversible":
                    assert np.all(rows[:, 2] == 0)
                backend[f"{name}_{dt}"] = {
                    "decline_pct": predicted,
                    "balance": err,
                    "alpha": alpha,
                    "history": rows.tolist(),
                }
                previous = predicted
        zero, _, _ = replay(gas, device, 300, nitrogen=False, end=20)
        assert np.all(zero[:, 2] == 0) and zero[-1, 3] > 0
        report["runs"][device] = backend
    for ph in YU:
        if ph == 3.5:
            history = np.array(report["runs"]["numpy"]["IC_75"]["history"])
        else:
            history, _, _ = replay(gas, "numpy", 75, ph=ph)
        report["pH_sensitivity"][str(ph)] = float(history[-1, 2])
    for name in ("reversible_75", "IC_75"):
        cpu = np.array(report["runs"]["numpy"][name]["history"])
        gpu = np.array(report["runs"]["cuda:0"][name]["history"])
        diff = abs(
            report["runs"]["numpy"][name]["decline_pct"]
            - report["runs"]["cuda:0"][name]["decline_pct"]
        )
        assert diff < resolution
        assert np.max(np.abs(cpu[:, 1:3] - gpu[:, 1:3])) < 0.01
    return report


# %% [markdown]
# <a id="compare-the-release-and-the-persistent-product"></a>
#
# ### Organic mass per sulfate falls as the nitrogen marker rises
#
# The organic-to-sulfate panel compares dry organic mass with sulfate ion
# mass. Retain all digitized observations from seed injection onward. The
# chamber instrument did not supply a calibrated IC mass. Normalize the
# measured fragment and modeled IC separately to their medians just before
# dilution so that only the direction and timing can be compared.


# %%
def plot_results(report):
    obs = {k: np.array(v) for k, v in report["observed"].items()}
    fig, axes = plt.subplots(
        3, 1, figsize=(8, 8.5), sharex=True, layout="constrained"
    )

    def markers(ax, series, label):
        t, y = series.T
        ax.scatter(
            t / 60,
            y,
            s=4,
            color="#626569",
            alpha=0.5,
            label=label,
            rasterized=True,
        )

    markers(axes[0], obs["gas_ppbv"], "Figure 6 · prescribed")
    markers(axes[1], obs["organic_per_sulfate"], "Figure 6 · observed")
    for key, label, color in (
        ("reversible_75", "Reversible exchange", "#19717b"),
        ("IC_75", "Exchange and IC formation", "#a04c22"),
    ):
        h = np.array(report["runs"]["numpy"][key]["history"])
        axes[1].plot(h[:, 0] / 60, h[:, 1], label=label, color=color, lw=2)
    fit = report["chamber_fit"]
    time, ratio = np.transpose(fit["history"])
    for mask, style, label in (
        (time <= fit["fit_end_min"], "-", "Chamber fit · growth"),
        (time >= fit["fit_end_min"], "--", "Prediction · dilution"),
    ):
        axes[1].plot(
            time[mask] / 60,
            ratio[mask],
            ls=style,
            color="#554990",
            label=label,
            lw=2,
        )
    marker = obs["marker68_per_sulfate"].copy()
    t, y = marker.T
    marker[:, 1] /= np.median(y[(t >= DILUTION - 20) & (t <= DILUTION)])
    markers(axes[2], marker, "Figure 6 · m/z 68")
    t, p = h[:, 0], h[:, 2]
    axes[2].plot(
        t / 60,
        p / np.median(p[(t >= DILUTION - 20) & (t <= DILUTION)]),
        color="#a04c22",
        label="Modeled IC",
    )
    for ax, label in zip(
        axes,
        (
            "Gas glyoxal (ppbv)",
            "Organic / sulfate (kg/kg)",
            "Relative to pre-dilution",
        ),
        strict=True,
    ):
        ax.axvline(DILUTION / 60, color="#48494b", ls="--", lw=1)
        ax.set_ylabel(label)
        ax.spines[["right", "top"]].set_visible(False)
        ax.legend(frameon=False, loc="best", fontsize=8)
    axes[1].legend(
        loc="lower left",
        bbox_to_anchor=(0, 1.01),
        ncol=3,
        frameon=False,
        fontsize=8,
        borderaxespad=0,
    )
    axes[0].set_title(
        "Glyoxal in a dark chamber with wet ammonium sulfate", loc="left"
    )
    axes[0].text(
        DILUTION / 60 + 0.25,
        0.08,
        "Dilution",
        transform=axes[0].get_xaxis_transform(),
    )
    axes[-1].set(xlabel="Time since seed injection (h)", xlim=(0, END / 60))
    return fig


def summarize(report):
    print(
        f"Measured organic/sulfate fell {report['measured_decline_pct']:.2f}%."
    )
    fit = report["chamber_fit"]
    before, after = fit["window_ratios"]
    print(
        f"Chamber fit: K = {fit['capacity_ratio_per_ppbv']:.4f} per ppbv, "
        f"response time {fit['tau_hours']:.2f} h. "
        f"Predicted organic/sulfate {before:.2f} to {after:.2f}, "
        f"a {fit['decline_pct']:.2f}% decline."
    )
    for device, runs in report["runs"].items():
        for key in ("reversible_75", "IC_75"):
            run = runs[key]
            change = run["decline_pct"]
            direction = "fell" if change > 0 else "rose"
            name = (
                "Reversible pools"
                if key.startswith("reversible")
                else "With IC"
            )
            coarse = runs[key.replace("75", "150")]["decline_pct"]
            print(
                f"{device} · {name} · organic/sulfate {direction} {abs(change):.2f}%; "
                f"refinement {abs(coarse - change):.3f} percentage points; "
                f"maximum relative inventory error {run['balance']:.2g}."
            )
        final = runs["IC_75"]["history"][-1]
        print(
            f"Cumulative modeled evaporation {final[8] * 1e9:.2f} µg/m³; "
            f"final ammonium sulfate molality {final[9]:.2f} mol/kg."
        )
    print(
        "Final IC / sulfate (kg/kg), prescribed pH:", report["pH_sensitivity"]
    )
    print(
        f"Digitization allowance: {report['digitizing_pp']:.3f} percentage points."
    )


# %% [markdown]
# <a id="what-the-comparison-tells-us"></a>
#
# <a id="the-two-particle-models-keep-accumulating-organics-after-dilution"></a>
#
# ### Only the growth-calibrated reservoir turns down with the measurements
#
# In the middle panel, the measured organic-to-sulfate ratio falls from
# 3.066 to 2.753 between the two sampling windows. The fitted reservoir
# falls from 3.01 to 2.81. Its 6.9-hour response time was estimated from
# the growth period. The two particle models are still filling their
# reversible pools at dilution. Even when the reaction model releases vapor
# during individual intervals, its final particle organic mass exceeds its
# pre-dilution value. In the lower panel, the measured nitrogen fragment
# approximately doubles. The two traces there have separate normalizations.

# %%
if __name__ == "__main__":
    results = simulate()
    summarize(results)
    plot_results(results)
    plt.show()

# %% [markdown]
# ## Product calibration would test how much organic mass chemistry retains
#
# The growth fit captures the direction of release using an effective capacity
# and response time. Several processes contribute to those fitted quantities,
# including water uptake and reversible chemical storage. The fragment trace
# offers a separate test of product timing, but its response per unit product
# mass is unknown. Simultaneous measurements of particle acidity and calibrated
# IC abundance during dilution would test whether the model retains the right
# amount of glyoxal as IC as the total organic-to-sulfate ratio falls.
#
# ## Reproducing the dilution comparison
#
# The study download includes the three digitized Figure 6 series, their
# extraction notes and the reaction mechanism. The saved output includes the
# fitting window, fitted parameters, model histories and pH sensitivity. To
# repeat the registered CPU and CUDA calculations from a checkout, run
# `python scripts/docs_examples.py refresh glyoxal-chamber` with CUDA available.
