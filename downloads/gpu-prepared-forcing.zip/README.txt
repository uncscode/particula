Extract this entire archive into one directory. Install the Particula version documented on the study page and its optional dependencies. From the extracted directory run:

python example.py --cuda

Helper/data paths are preserved below that directory. CUDA studies require an available NVIDIA GPU and Warp.
Scientific package revision: 480ecf2c1aa95da42985098c53e4ecdc66133d7b
