Extract this entire archive into one directory. Install the Particula version documented on the study page and its optional dependencies. From the extracted directory run:

python example.py --cuda

Helper/data paths are preserved below that directory. CUDA studies require an available NVIDIA GPU and Warp.
Scientific package revision: 3d3753d2be9973c94b4064047fa8452e717f1311
