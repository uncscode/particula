Extract this entire archive into one directory. Install the Particula version documented on the example page and its optional dependencies. From the extracted directory run:

python example.py

Helper/data paths are preserved below that directory. CUDA examples require an available NVIDIA GPU and Warp.
