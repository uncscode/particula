Replot with Python 3.12, NumPy and Matplotlib.
python exploration_figures.py --from-values . --output figures
python kernel_transfer_figures.py --from-values . --output figures
CSV files store the plotted values. Source checksums refer to paths in measurements.zip.
